# Add new mime types for use in respond_to blocks:
